<script setup>
import { computed } from 'vue';
import { getSizeProps } from '../helpers/size.js';
import '../css/testfvxq6s.css';
import '../css/test4qejly.css';
import '../css/testh9vftg.css';
import '../css/testc49-qf.css';
import '../css/testlbeskt.css';

const props = defineProps(["width","height"]);

const viewBox = '0 0 80 80';
const size = computed(() => getSizeProps(props.width, props.height, 1));
const content = `<g class="testfvxq6s"><path clip-rule="evenodd" class="test4qejly"/><path class="testh9vftg"/><path clip-rule="evenodd" class="testc49-qf"/><path class="testlbeskt"/></g>`;
</script>
<template><svg xmlns="http://www.w3.org/2000/svg" v-bind="size" :viewBox="viewBox" v-html="content" /></template>
