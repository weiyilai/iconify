import { Icon } from '@iconify/css-solid';
import { splitProps } from 'solid-js';
import '../css/testtxyhnm.css';
import '../css/testbhikax.css';
import '../css/testg3tz2l.css';
import '../css/testtgk04h.css';

const viewBox = {"width":80,"height":80};
const content = `<g clip-rule="evenodd" class="testtxyhnm"><path class="testbhikax"/><path class="testg3tz2l"/><path class="testtgk04h"/></g>`;

/** @param props {{width?: string; height?: string;}} */
function Component(props) {
	const [local, others] = splitProps(props, ["width","height"]);

	return (<Icon width={local.width} height={local.height} viewBox={viewBox} content={content} fallback={"glyphs-poly:bell"} {...others} />);
}

export default Component;
