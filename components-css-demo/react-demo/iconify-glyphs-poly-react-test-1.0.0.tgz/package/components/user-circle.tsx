import { createElement, useMemo } from 'react';
import { getSizeProps } from '../helpers/size.js';
import { cleanupHTML } from '../helpers/innerhtml.js';
import '../css/testfvxq6s.css';
import '../css/testoruh2h.css';
import '../css/testeuh58k.css';
import '../css/testpqhldd.css';
import '../css/testfe8ygo.css';

const viewBox = '0 0 80 80';
const content = {__html: cleanupHTML(`<g class="testfvxq6s"><path class="testoruh2h"/><path class="testeuh58k"/><path clip-rule="evenodd" class="testpqhldd"/><path class="testfe8ygo"/></g>`)};

interface Props {
	width?: string;
	height?: string;
};

function Component({width, height, ...props}: Props) {
	const size = useMemo(() => getSizeProps(width, height, 1), [width, height]);
	return createElement('svg', {
		"xmlns": "http://www.w3.org/2000/svg",
		...props,
		...size,
		viewBox,
		dangerouslySetInnerHTML: content,
	});
}

export default Component;
