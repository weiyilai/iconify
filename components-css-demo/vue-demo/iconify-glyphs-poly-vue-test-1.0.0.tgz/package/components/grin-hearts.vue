<script setup lang="ts">
import { Icon } from '@iconify/css-vue';
import '../css/testfvxq6s.css';
import '../css/testi4gpez.css';
import '../css/testjj7jbj.css';
import '../css/testk320xs.css';
import '../css/testflufzz.css';

const props = defineProps<{
	width?: string;
	height?: string;
}>();

const viewBox = {"width":80,"height":80};
const content = `<g class="testfvxq6s"><path class="testi4gpez"/><path clip-rule="evenodd" class="testjj7jbj"/><path class="testk320xs"/><path clip-rule="evenodd" class="testflufzz"/></g>`;
</script>
<template><Icon :width="width" :height="height" :viewBox="viewBox" :content="content" fallback="glyphs-poly:grin-hearts" /></template>
