<script>
import Icon from '@iconify/css-svelte';
import '../css/testfvxq6s.css';
import '../css/testi4gpez.css';
import '../css/testjj7jbj.css';
import '../css/testk320xs.css';
import '../css/testflufzz.css';

/** @type {{width?: string; height?: string;}} */
let {width, height, ...props} = $props();

const viewBox = {"width":80,"height":80};
const content = `<g class="testfvxq6s"><path class="testi4gpez"/><path clip-rule="evenodd" class="testjj7jbj"/><path class="testk320xs"/><path clip-rule="evenodd" class="testflufzz"/></g>`;
</script>
<Icon width={width} height={height} viewBox={viewBox} content={content} fallback="glyphs-poly:grin-hearts" {...props}></Icon>
