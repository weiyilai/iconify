<script setup>
import { Icon } from '@iconify/css-vue';
import '../css/testtxyhnm.css';
import '../css/testbhikax.css';
import '../css/testg3tz2l.css';
import '../css/testtgk04h.css';

const props = defineProps(["width","height"]);

const viewBox = {"width":80,"height":80};
const content = `<g clip-rule="evenodd" class="testtxyhnm"><path class="testbhikax"/><path class="testg3tz2l"/><path class="testtgk04h"/></g>`;
</script>
<template><Icon :width="width" :height="height" :viewBox="viewBox" :content="content" fallback="glyphs-poly:bell" /></template>
