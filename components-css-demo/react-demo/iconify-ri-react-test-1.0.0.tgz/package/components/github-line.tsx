import { createElement, useMemo } from 'react';
import { getSizeProps } from '../helpers/size.js';
import { cleanupHTML } from '../helpers/innerhtml.js';
import '../css/testo40dnh.css';

const viewBox = '0 0 24 24';
const content = {__html: cleanupHTML(`<path class="testo40dnh"/>`)};

interface Props {
	width?: string;
	height?: string;
};

function Component({width, height, ...props}: Props) {
	const size = useMemo(() => getSizeProps(width, height, 1), [width, height]);
	return createElement('svg', {
		"xmlns": "http://www.w3.org/2000/svg",
		...props,
		...size,
		viewBox,
		dangerouslySetInnerHTML: content,
	});
}

export default Component;
