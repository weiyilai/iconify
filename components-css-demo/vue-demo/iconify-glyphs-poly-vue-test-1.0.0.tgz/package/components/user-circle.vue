<script setup lang="ts">
import { computed } from 'vue';
import { getSizeProps } from '../helpers/size.js';
import '../css/testfvxq6s.css';
import '../css/testoruh2h.css';
import '../css/testeuh58k.css';
import '../css/testpqhldd.css';
import '../css/testfe8ygo.css';

const props = defineProps<{
	width?: string;
	height?: string;
}>();

const viewBox = '0 0 80 80';
const size = computed(() => getSizeProps(props.width, props.height, 1));
const content = `<g class="testfvxq6s"><path class="testoruh2h"/><path class="testeuh58k"/><path clip-rule="evenodd" class="testpqhldd"/><path class="testfe8ygo"/></g>`;
</script>
<template><svg xmlns="http://www.w3.org/2000/svg" v-bind="size" :viewBox="viewBox" v-html="content" /></template>
