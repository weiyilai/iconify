import { createMemo, splitProps } from 'solid-js';
import { getSizeProps } from '../helpers/size.js';
import '../css/testfvxq6s.css';
import '../css/testoruh2h.css';
import '../css/testeuh58k.css';
import '../css/testpqhldd.css';
import '../css/testfe8ygo.css';

const viewBox = '0 0 80 80';
const content = `<g class="testfvxq6s"><path class="testoruh2h"/><path class="testeuh58k"/><path clip-rule="evenodd" class="testpqhldd"/><path class="testfe8ygo"/></g>`;

interface Props {
	width?: string;
	height?: string;
};

function Component(props: Props) {
	const [local, others] = splitProps(props, ["width","height"]);

	const size = createMemo(() => getSizeProps(local.width, local.height, 1));
	return (<svg xmlns="http://www.w3.org/2000/svg" {...size()} viewBox={viewBox} innerHTML={content} {...others} />);
}

export default Component;
