<script>
import { getSizeProps } from '../helpers/size.js';
import '../css/testfvxq6s.css';
import '../css/testoruh2h.css';
import '../css/testeuh58k.css';
import '../css/testpqhldd.css';
import '../css/testfe8ygo.css';

/** @type {{width?: string; height?: string;}} */
let {width, height, ...props} = $props();

const viewBox = '0 0 80 80';
let size = $derived(getSizeProps(width, height, 1));
const content = `<g class="testfvxq6s"><path class="testoruh2h"/><path class="testeuh58k"/><path clip-rule="evenodd" class="testpqhldd"/><path class="testfe8ygo"/></g>`;
</script>
<svg xmlns="http://www.w3.org/2000/svg" {...size} viewBox={viewBox} {...props}>{@html content}</svg>
