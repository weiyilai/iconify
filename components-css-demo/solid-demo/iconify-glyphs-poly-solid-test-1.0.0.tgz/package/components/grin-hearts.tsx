import { Icon } from '@iconify/css-solid';
import { splitProps } from 'solid-js';
import '../css/testfvxq6s.css';
import '../css/testi4gpez.css';
import '../css/testjj7jbj.css';
import '../css/testk320xs.css';
import '../css/testflufzz.css';

const viewBox = {"width":80,"height":80};
const content = `<g class="testfvxq6s"><path class="testi4gpez"/><path clip-rule="evenodd" class="testjj7jbj"/><path class="testk320xs"/><path clip-rule="evenodd" class="testflufzz"/></g>`;

interface Props {
	width?: string;
	height?: string;
};

function Component(props: Props) {
	const [local, others] = splitProps(props, ["width","height"]);

	return (<Icon width={local.width} height={local.height} viewBox={viewBox} content={content} fallback={"glyphs-poly:grin-hearts"} {...others} />);
}

export default Component;
