<script setup>
import { computed } from 'vue';
import { getSizeProps } from '../helpers/size.js';
import '../css/testmy5efa.css';

const props = defineProps(["width","height"]);

const viewBox = '0 0 24 24';
const size = computed(() => getSizeProps(props.width, props.height, 1));
const content = `<path class="testmy5efa"/>`;
</script>
<template><svg xmlns="http://www.w3.org/2000/svg" v-bind="size" :viewBox="viewBox" v-html="content" /></template>
