import { Icon } from '@iconify/css-react';
import { createElement } from 'react';
import '../css/testtxyhnm.css';
import '../css/testbhikax.css';
import '../css/testg3tz2l.css';
import '../css/testtgk04h.css';

const viewBox = {"width":80,"height":80};

/** @param {{width?: string; height?: string;}} */
function Component({width, height, ...props}) {
	return createElement(Icon, {
		...props,
		width,
		height,
		viewBox,
		"content": `<g clip-rule="evenodd" class="testtxyhnm"><path class="testbhikax"/><path class="testg3tz2l"/><path class="testtgk04h"/></g>`,
		"fallback": "glyphs-poly:bell",
	});
}

export default Component;
