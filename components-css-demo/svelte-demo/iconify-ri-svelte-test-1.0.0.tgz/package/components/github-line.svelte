<script>
import { getSizeProps } from '../helpers/size.js';
import '../css/testo40dnh.css';

/** @type {{width?: string; height?: string;}} */
let {width, height, ...props} = $props();

const viewBox = '0 0 24 24';
let size = $derived(getSizeProps(width, height, 1));
const content = `<path class="testo40dnh"/>`;
</script>
<svg xmlns="http://www.w3.org/2000/svg" {...size} viewBox={viewBox} {...props}>{@html content}</svg>
