import { Icon } from '@iconify/css-react';
import { createElement } from 'react';
import '../css/test78832u.css';

const viewBox = {"width":24,"height":24};

interface Props {
	width?: string;
	height?: string;
};

function Component({width, height, ...props}: Props) {
	return createElement(Icon, {
		...props,
		width,
		height,
		viewBox,
		"content": `<path class="test78832u"/>`,
		"fallback": "ri:twitter-x-line",
	});
}

export default Component;
