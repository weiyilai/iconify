<script>
import Icon from '@iconify/css-svelte';
import '../css/testtxyhnm.css';
import '../css/testbhikax.css';
import '../css/testg3tz2l.css';
import '../css/testtgk04h.css';

/** @type {{width?: string; height?: string;}} */
let {width, height, ...props} = $props();

const viewBox = {"width":80,"height":80};
const content = `<g clip-rule="evenodd" class="testtxyhnm"><path class="testbhikax"/><path class="testg3tz2l"/><path class="testtgk04h"/></g>`;
</script>
<Icon width={width} height={height} viewBox={viewBox} content={content} fallback="glyphs-poly:bell" {...props}></Icon>
