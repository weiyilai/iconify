import { createMemo, splitProps } from 'solid-js';
import { getSizeProps } from '../helpers/size.js';
import '../css/testo40dnh.css';

const viewBox = '0 0 24 24';
const content = `<path class="testo40dnh"/>`;

interface Props {
	width?: string;
	height?: string;
};

function Component(props: Props) {
	const [local, others] = splitProps(props, ["width","height"]);

	const size = createMemo(() => getSizeProps(local.width, local.height, 1));
	return (<svg xmlns="http://www.w3.org/2000/svg" {...size()} viewBox={viewBox} innerHTML={content} {...others} />);
}

export default Component;
