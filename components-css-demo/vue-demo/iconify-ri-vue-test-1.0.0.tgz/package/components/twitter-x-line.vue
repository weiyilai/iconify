<script setup lang="ts">
import { Icon } from '@iconify/css-vue';
import '../css/test78832u.css';

const props = defineProps<{
	width?: string;
	height?: string;
}>();

const viewBox = {"width":24,"height":24};
const content = `<path class="test78832u"/>`;
</script>
<template><Icon :width="width" :height="height" :viewBox="viewBox" :content="content" fallback="ri:twitter-x-line" /></template>
