import { Icon } from '@iconify/css-react';
import { createElement } from 'react';
import '../css/testfvxq6s.css';
import '../css/testi4gpez.css';
import '../css/testjj7jbj.css';
import '../css/testk320xs.css';
import '../css/testflufzz.css';

const viewBox = {"width":80,"height":80};

interface Props {
	width?: string;
	height?: string;
};

function Component({width, height, ...props}: Props) {
	return createElement(Icon, {
		...props,
		width,
		height,
		viewBox,
		"content": `<g class="testfvxq6s"><path class="testi4gpez"/><path clip-rule="evenodd" class="testjj7jbj"/><path class="testk320xs"/><path clip-rule="evenodd" class="testflufzz"/></g>`,
		"fallback": "glyphs-poly:grin-hearts",
	});
}

export default Component;
