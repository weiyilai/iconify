import { createElement, useMemo } from 'react';
import { getSizeProps } from '../helpers/size.js';
import { cleanupHTML } from '../helpers/innerhtml.js';
import '../css/testfvxq6s.css';
import '../css/test4qejly.css';
import '../css/testh9vftg.css';
import '../css/testc49-qf.css';
import '../css/testlbeskt.css';

const viewBox = '0 0 80 80';
const content = {__html: cleanupHTML(`<g class="testfvxq6s"><path clip-rule="evenodd" class="test4qejly"/><path class="testh9vftg"/><path clip-rule="evenodd" class="testc49-qf"/><path class="testlbeskt"/></g>`)};

/** @param {{width?: string; height?: string;}} */
function Component({width, height, ...props}) {
	const size = useMemo(() => getSizeProps(width, height, 1), [width, height]);
	return createElement('svg', {
		"xmlns": "http://www.w3.org/2000/svg",
		...props,
		...size,
		viewBox,
		dangerouslySetInnerHTML: content,
	});
}

export default Component;
