<script setup lang="ts">
import { computed } from 'vue';
import { getSizeProps } from '../helpers/size.js';
import '../css/testo40dnh.css';

const props = defineProps<{
	width?: string;
	height?: string;
}>();

const viewBox = '0 0 24 24';
const size = computed(() => getSizeProps(props.width, props.height, 1));
const content = `<path class="testo40dnh"/>`;
</script>
<template><svg xmlns="http://www.w3.org/2000/svg" v-bind="size" :viewBox="viewBox" v-html="content" /></template>
