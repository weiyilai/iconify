import { createMemo, splitProps } from 'solid-js';
import { getSizeProps } from '../helpers/size.js';
import '../css/testfvxq6s.css';
import '../css/test4qejly.css';
import '../css/testh9vftg.css';
import '../css/testc49-qf.css';
import '../css/testlbeskt.css';

const viewBox = '0 0 80 80';
const content = `<g class="testfvxq6s"><path clip-rule="evenodd" class="test4qejly"/><path class="testh9vftg"/><path clip-rule="evenodd" class="testc49-qf"/><path class="testlbeskt"/></g>`;

/** @param props {{width?: string; height?: string;}} */
function Component(props) {
	const [local, others] = splitProps(props, ["width","height"]);

	const size = createMemo(() => getSizeProps(local.width, local.height, 1));
	return (<svg xmlns="http://www.w3.org/2000/svg" {...size()} viewBox={viewBox} innerHTML={content} {...others} />);
}

export default Component;
